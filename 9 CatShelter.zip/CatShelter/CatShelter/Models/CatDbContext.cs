﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CatShelter.Models.Entities
{
    public partial class CatDbContext : DbContext
    {
        public CatDbContext(DbContextOptions<CatDbContext> options) : base(options)
        {
        }

        internal void AddCat(CatsCreateVM model)
        {
            var cat = new Cat
            {
                Name = model.Name,
                Anger = model.Anger,
                Weight = model.Weight,
            };

            Cat.Add(cat);
            SaveChanges();
        }

        public CatsIndexVM[] ListCats()
        {
            return this.Cat
                .Select(o => new CatsIndexVM
                {
                    Name = o.Name,
                    IsAggressive = o.Anger > 7
                })
                .ToArray();
        }
    }
}
