﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CatShelter.Models.Entities
{
    public partial class CatDbContext : DbContext
    {
        public DbSet<Cat> Cat { get; set; }
    }
}
