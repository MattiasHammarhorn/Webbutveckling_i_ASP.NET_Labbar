﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using CatShelter.Models.Entities;
using CatShelter.Models;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace CatShelter.Controllers
{
    public class CatsController : Controller
    {
        CatDbContext context;
        public CatsController(CatDbContext context)
        {
            this.context = context;
        }

        // GET: /<controller>/
        public IActionResult Index()
        {
            var model = context.ListCats();
            return View(model);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Create(CatsCreateVM model)
        {
            if (!ModelState.IsValid)
                return View(model);

            // Add cat to DB
            context.AddCat(model);

            return RedirectToAction(nameof(CatsController.Index));
        }
    }
}
