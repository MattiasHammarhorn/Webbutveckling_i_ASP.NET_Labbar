﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace Webbutveckling_Tenta.Models.Entities
{
    public partial class MvcTentaContext
    {
        public MvcTentaContext(DbContextOptions<MvcTentaContext> options) : base(options)
        {
        }

        public ComputerIndexVM[] GetAllComputers()
        {
            string[] status = { "apple", "mac" };

            return Computers
                .Select(o => new ComputerIndexVM()
                {
                    Id = o.Id,
                    Manufacturer = o.Manufacturer,
                    Price = o.Price,
                    IsAppleOrMac = true ? status.Contains(o.Manufacturer.ToLower()) : false,
                })
                .ToArray();
        }

        public void AddComputerToDb(ComputerCreateVM viewModel)
        {
            var newComputer = new Computers()
            {
                Manufacturer = viewModel.Manufacturer,
                Price = viewModel.Price,
            };

            Computers.Add(newComputer);
            SaveChanges();
        }

        public ComputerEditVM GetComputer(int id)
        {
            var computer = Computers
                .SingleOrDefault(o => o.Id == id);

            return new ComputerEditVM()
            {
                Id = computer.Id,
                Manufacturer = computer.Manufacturer,
                Price = computer.Price,
            };
        }

        public void EditComputer(ComputerEditVM viewModel)
        {
            var computer = Computers
                .SingleOrDefault(o => o.Id == viewModel.Id);

            computer.Manufacturer = viewModel.Manufacturer;
            computer.Price = viewModel.Price;
            SaveChanges();
        }

    }
}
