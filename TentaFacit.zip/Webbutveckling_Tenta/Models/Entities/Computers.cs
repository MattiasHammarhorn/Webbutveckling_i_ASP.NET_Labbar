﻿using System;
using System.Collections.Generic;

namespace Webbutveckling_Tenta.Models.Entities
{
    public partial class Computers
    {
        public int Id { get; set; }
        public string Manufacturer { get; set; }
        public int Price { get; set; }
    }
}
