﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Webbutveckling_Tenta.Models
{
    public class ComputerCreateVM
    {
        [Display(Name = "Fabrikat")]
        [Required(ErrorMessage = "Fabrikat måste vara ifylld.")]
        public string Manufacturer { get; set; }

        [Display(Name = "Pris")]
        [Required(ErrorMessage = "Pris måste vara ifyllt.")]
        [Range(1, 30000, ErrorMessage = "Mata in ett tal mellan 1 och 30 000.")]
        public int Price { get; set; }
    }
}
