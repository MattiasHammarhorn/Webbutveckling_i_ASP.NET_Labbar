﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Webbutveckling_Tenta.Models;
using Webbutveckling_Tenta.Models.Entities;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Webbutveckling_Tenta.Controllers
{
    public class ComputersController : Controller
    {

        MvcTentaContext _context;

        public ComputersController(MvcTentaContext context)
        {
            _context = context;
        }

        [HttpGet]
        public IActionResult Index()
        {
            var model = _context.GetAllComputers();
            return View(model);
        }

        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Create(ComputerCreateVM viewModel)
        {
            if (!ModelState.IsValid)
                return View(viewModel);

            TempData["ConfirmationMsg"] = String.Format($"{viewModel.Manufacturer} computer has successfully been added to the database.");
            _context.AddComputerToDb(viewModel);

            return RedirectToAction(nameof(ComputersController.Index));
        }

        [HttpGet]
        public IActionResult Edit(int id)
        {
            var model = _context.GetComputer(id);
            return View(model);
        }

        [HttpPost]
        public IActionResult Edit(ComputerEditVM viewModel)
        {
            if (!ModelState.IsValid)
                return View(viewModel);

            TempData["ConfirmationMsg"] = String.Format($"{viewModel.Manufacturer} computer has successfully been edited.");
            _context.EditComputer(viewModel);

            return RedirectToAction(nameof(ComputersController.Index));
        }
    }
}
